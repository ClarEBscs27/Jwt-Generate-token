<?php
    require_once("function.php");
    echo generateToken();
?>