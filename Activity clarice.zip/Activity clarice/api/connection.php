<?php
    define("SEVER", "localhost");
    define("USERNAME", "root");
    define("DATABASE", "users");
    define("PASSWORD", "");
    $con=myqli_connect(SERVER, USERNAME, DATABASE, PASSWORD);
?>